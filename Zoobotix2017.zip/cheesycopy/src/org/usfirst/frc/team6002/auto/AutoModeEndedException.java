package org.usfirst.frc.team6002.auto;

public class AutoModeEndedException extends Exception {

    private static final long serialVersionUID = 1411131586291540143L;

}
