package org.usfirst.frc.team6002.robot;

public interface Loop {
	public void onStart();
	
	public void onLoop();
	
	public void onStop();
}
